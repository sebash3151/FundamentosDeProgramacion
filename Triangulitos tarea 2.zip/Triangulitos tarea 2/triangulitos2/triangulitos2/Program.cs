﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulitos2
{
    class Program
    {
        static void Main(string[] args)
        {
            //ingreso de datos
            Console.WriteLine("Ingrese d:");
            double d = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese b:");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese y:");
            double y = double.Parse(Console.ReadLine());

            //hallar a
            double a = 180 - 90 - d - b;
            double arad = a * (Math.PI / 180);
            Console.WriteLine("a es: " + a);

            //hallar z
            double z = y / Math.Tan(arad);
            Console.WriteLine("El lado z es: " + z);
        }
    }
}
