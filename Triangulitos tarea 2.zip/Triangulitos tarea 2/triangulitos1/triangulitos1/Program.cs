﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulitos1
{
    class Program
    {
        static void Main(string[] args)
        {
            //ingreso de datos
            Console.WriteLine("Ingrese b:");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese z:");
            double z = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese y:");
            double y = double.Parse(Console.ReadLine());

            //se haya el angulo a
            double a = Math.Atan(y / z);
            double agrados = a * (180/Math.PI);
            Console.WriteLine("a: " + agrados);

            //se calcula x
            double brad = b * (Math.PI/180);
            double x = (z * Math.Tan(a+brad)) - y;
            Console.WriteLine("El segmento x es: " + x);
        }
    }
}
