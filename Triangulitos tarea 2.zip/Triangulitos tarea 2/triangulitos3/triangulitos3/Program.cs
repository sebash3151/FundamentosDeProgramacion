﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulitos3
{
    class Program
    {
        static void Main(string[] args)
        {
            //ingreso de datos
            Console.WriteLine("Ingrese w:");
            double w = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese d:");
            double d = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese x:");
            double x = double.Parse(Console.ReadLine());

            //hallar y
            double drad = d * (Math.PI / 180);
            double y = (w * Math.Cos(drad)) - x;
            Console.WriteLine("El segmento y es: " + y);
        }
    }
}
