﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulitos4
{
    class Program
    {
        static void Main(string[] args)
        {
            //ingreso de datos
            Console.WriteLine("Ingrese w:");
            double w = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese t:");
            double t = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese c:");
            double c = double.Parse(Console.ReadLine());

            //hallar z
            double crad = c * (Math.PI / 180);
            double z = t * Math.Sin(crad);
            Console.WriteLine("z es:" + z);

            //hallamos a + b = h
            double h = Math.Acos(z / w);
            double hgrados = h * (180 / Math.PI);
            Console.WriteLine("h es:" + hgrados);

            //hallar y
            double y = Math.Cos(crad) * t;
            Console.WriteLine("y es: " + y);

            //hallamos finalmente y con mucho sueño x
            double x = Math.Sin(h) * w - y;
            Console.WriteLine("su pinche x es:" + x);
        }
    }
}
