﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp22
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            int edadmax = 0;
            string nombremax = "";
            int edadmin = 100000;
            string nombremin = "";
            int total = 0;
            double promedioXD = 0;
            double desviasionOMG = 0;
            string nombrecercanopromedio777 = "";
            double desviacionminima = 1000;
            int a = 0;
            string nombreA = "";
            int b = 10000;
            string nombreB = "";

            Console.WriteLine("Ingrese el número de personas a ingresar: ");
            int n = int.Parse(Console.ReadLine());

            int[] edades = new int[n];
            string[] nombres = new string[n];

            for (i = 0; i < edades.Length; i++)
            {
                Console.WriteLine("Ingrese el nombre " + (i+1));
                nombres[i] = Console.ReadLine();

                Console.WriteLine("Ingrese la edad " + (i+1));
                edades[i] = int.Parse(Console.ReadLine());

                if (edades[i] > edadmax)
                {
                    edadmax = edades[i];
                    nombremax = nombres[i];
                }

                if (edades[i] < edadmin)
                {
                    edadmin = edades[i];
                    nombremin = nombres[i];
                }

                //promedio 
                total += edades[i];
                promedioXD = total / n;
        
            }

            for (i = 0; i < edades.Length; i++)
            {
                double partedearriba = Math.Pow(total - promedioXD, 2);
                desviasionOMG = Math.Sqrt(partedearriba / n);

            }

            for (i = 0; i < edades.Length; i++)
            {
                if (edades[i] >= a && edades[i] >= promedioXD)
                {
                    a = edades[i];
                    nombreA = nombres[i];
                }

                if (edades[i] <= b && edades[i] <= promedioXD)
                {
                    b = edades[i];
                    nombreB = nombres[i];
                }

                double S1 = promedioXD - a;
                double S2 = b - promedioXD;

                if (S1 < S2)
                {
                    Console.WriteLine("Cercano: " + nombreA);
                }else if (S2 < S1) {
                    Console.WriteLine("Cercano: " + nombreB);
                }
            }

            Console.WriteLine("Edad Máxima: " + edadmax + " de " + nombremax);
            Console.WriteLine("Edad Mínima: " + edadmin + " de " + nombremin);
            Console.WriteLine("Promedio: " + promedioXD);
            Console.WriteLine("Desviacion: " + desviasionOMG);
            Console.WriteLine("Nombre cercano al promedio: " + nombrecercanopromedio777);

            
        }
    }
}
