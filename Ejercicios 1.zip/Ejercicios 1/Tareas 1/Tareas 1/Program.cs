﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tareas_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese y:");
            double y = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese z:");
            double z = double.Parse(Console.ReadLine());

            //calculo de la hipotenusa

            double hipo = Math.Sqrt((y * y) + (z * z));
            Console.WriteLine("la hiponusa es: " + hipo);

            //calculo de angulos
            double C = Math.Asin(z / hipo);
            double A = Math.Asin(y / hipo);

            //pasar a grados
            double cgrados = C * (180 / Math.PI);
            double agrados = A * (180 / Math.PI);

            //mostrar solucion
            Console.WriteLine("El ángulo c es: " + cgrados);
            Console.WriteLine("El ángulo a es: " + agrados);
        }
    }
}
