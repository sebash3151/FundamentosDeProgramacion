﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tareas_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //ingreso de datos
            Console.WriteLine("Ingrese c:");
            double c = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese z:");
            double z = double.Parse(Console.ReadLine());

            //pasar a radianes
            double cgrados = c * (Math.PI / 180);

            //calculo de resultados            
            double T = z/Math.Sin(cgrados);
            double y = Math.Cos(cgrados) * T;
            double a = 180 - 90 - c;

            //mostrar solucion
            Console.WriteLine("La hipotenusa es: " + T);
            Console.WriteLine("El cateto y es: " + y);
            Console.WriteLine("El ángulo a es: " + a);
        }
    }
}
