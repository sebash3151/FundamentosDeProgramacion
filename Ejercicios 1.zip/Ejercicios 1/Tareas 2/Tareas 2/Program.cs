﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tareas_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //ingreso de datos

            Console.WriteLine("Ingrese t:");
            double t = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese a:");
            double a = double.Parse(Console.ReadLine());

            //pasar a radianes
            double agrados = a * (Math.PI / 180);

            //calculo de resultados
            double y = Math.Sin(agrados) * t;
            double z = Math.Cos(agrados) * t;
            double c = 180 - 90 - a;

            //mostrar solucion
            Console.WriteLine("El cateto y es: " + y);
            Console.WriteLine("El cateto z es: " + z);
            Console.WriteLine("El ángulo c es: " + c);
        }
    }
}
