﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            double max=0;

            double[] CoordsX = new double[4];
            CoordsX[0] = 0;
            CoordsX[1] = 2;
            CoordsX[2] = 3;
            CoordsX[3] = 7;

            double[] CoordsY = new double[4];
            CoordsY[0] = 0;
            CoordsY[1] = 1;
            CoordsY[2] = 5;
            CoordsY[3] = 6;

            //colinealidad
            double BAx = CoordsX[0] - CoordsX[1];
            double BAy = CoordsY[0] - CoordsY[1];
            Console.WriteLine(BAx + "," + BAy);

            double BCx = CoordsX[2] - CoordsX[1];
            double BCy = CoordsY[2] - CoordsY[1];
            Console.WriteLine(BCx + "," + BCy);

            double BDx = CoordsX[3] - CoordsX[1];
            double BDy = CoordsY[3] - CoordsY[1];
            Console.WriteLine(BDx + "," + BDy);

            Console.WriteLine("NO SON COLIENALES ALV");

            //mayor distancia 

            double dAB = Math.Pow(Math.Pow((CoordsX[0] - CoordsX[1]), 2) + Math.Pow(CoordsY[0]-CoordsY[1],2), 1 / 2);
            if (dAB > 0)
            {
                max = dAB;
            }
            double dAC = Math.Pow(Math.Pow((CoordsX[0] - CoordsX[2]), 2) + Math.Pow(CoordsY[0] - CoordsY[2], 2), 1 / 2);
            if (dAC > dAB)
            {
                max = dAC;
            }
            double dAD = Math.Pow(Math.Pow((CoordsX[0] - CoordsX[3]), 2) + Math.Pow(CoordsY[0] - CoordsY[3], 2), 1 / 2);
            if (dAD > dAC)
            {
                max = dAD;
            }
            double dBC = Math.Pow(Math.Pow((CoordsX[1] - CoordsX[2]), 2) + Math.Pow(CoordsY[1] - CoordsY[2], 2), 1 / 2);
            if (dBC > dAC)
            {
                max = dBC;
            }
            double dBD = Math.Pow(Math.Pow((CoordsX[1] - CoordsX[3]), 2) + Math.Pow(CoordsY[1] - CoordsY[3], 2), 1 / 2);
            if (dBD > dBC)
            {
                max = dBD;
            }
            double dCD = Math.Pow(Math.Pow((CoordsX[2] - CoordsX[3]), 2) + Math.Pow(CoordsY[2] - CoordsY[3], 2), 1 / 2);
            if (dCD > dBC)
            {
                max = dCD;
            }

            Console.WriteLine("La mayor distancia pertenece a: " + max);
        }
    }
}
